---
layout: default
title: Sobre Nosotros
---
# Sobre KASAÉKO

En KASAÉKO nos dedicamos a ofrecer productos ecológicos y funcionales para tu hogar y cocina. 
Nuestra misión es promover un estilo de vida sostenible sin renunciar al diseño y la calidad.
