---
layout: default
title: Contacto
---
# Contacto

Para consultas y soporte, escríbenos a **contacto@kasaeko.com** o usa el formulario:
<form action="https://formspree.io/f/{tu_form_id}" method="POST">
  <input type="email" name="_replyto" placeholder="Tu email" required>
  <textarea name="message" placeholder="Tu mensaje" required></textarea>
  <button type="submit">Enviar</button>
</form>
